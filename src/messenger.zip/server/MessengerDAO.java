package messenger.server;

public class MessengerDAO {

}
