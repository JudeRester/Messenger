package messenger.common;

public class MemberDTO {

}
