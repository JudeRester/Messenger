package messenger.client;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Join extends JFrame{
	private JPanel contentPane;
	private JTextField id, birth, phno;
	private JPasswordField passwd;
	private JPasswordField passch;
	private final ButtonGroup buttonGroup = new ButtonGroup();


	public Join(JFrame frame, String title) {
		
		setBounds(100, 100, 261, 332);
		setResizable(false);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(0, 2, 0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("아이디");
		panel_1.add(lblNewLabel_1);
		
		id = new JTextField();
		panel_1.add(id);
		id.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("패스워드");
		panel_1.add(lblNewLabel_2);
		
		passwd = new JPasswordField();
		panel_1.add(passwd);
		
		JLabel lblNewLabel_3 = new JLabel("패스워드 확인");
		panel_1.add(lblNewLabel_3);
		
		passch = new JPasswordField();
		panel_1.add(passch);
		
		JLabel lblNewLabel_4 = new JLabel("지역");
		panel_1.add(lblNewLabel_4);
		String[] item = {"서울","경기","부산","광주","인천","대구","대전","청주"};
		JComboBox loc = new JComboBox(item);
		panel_1.add(loc);
		
		JLabel lblNewLabel_5 = new JLabel("성별");
		panel_1.add(lblNewLabel_5);
		
		JPanel panel_2 = new JPanel();
		panel_1.add(panel_2);
		
		JRadioButton radioButton = new JRadioButton("남");
		buttonGroup.add(radioButton);
		panel_2.add(radioButton);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("여");
		buttonGroup.add(rdbtnNewRadioButton);
		panel_2.add(rdbtnNewRadioButton);
		
		JLabel lblNewLabel_6 = new JLabel("생년월일");
		panel_1.add(lblNewLabel_6);
		
		birth = new JTextField();
		panel_1.add(birth);
		birth.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("휴대폰번호");
		panel_1.add(lblNewLabel_7);
		
		phno = new JTextField();
		panel_1.add(phno);
		phno.setColumns(10);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("회원가입");
		panel.add(lblNewLabel);
		
		JButton joinb = new JButton("가입");
		panel_1.add(joinb);
		joinb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				char[] pass = passwd.getPassword();
				String pass_1;
				String gibonCode="";
				pass_1 = new String(pass, 0, pass.length);
				Enumeration<AbstractButton> enums = buttonGroup.getElements();
				
				while(enums.hasMoreElements()) {            // hasMoreElements() Enum에 더 꺼낼 개체가 있는지 체크한다. 없으며 false 반환
				    AbstractButton ab = enums.nextElement();    // 제네릭스가 AbstractButton 이니까 당연히 AbstractButton으로 받아야함
				    JRadioButton jb = (JRadioButton)ab;         // 형변환. 물론 윗줄과 이줄을 합쳐서 바로 형변환 해서 받아도 된다.
				 
				    if(jb.isSelected())                         // 받아낸 라디오버튼의 체크 상태를 확인한다. 체크되었을경우 true 반환.
				        gibonCode = jb.getText().trim(); //getText() 메소드로 문자열 받아낸다.
				}
				StringBuffer cont = new StringBuffer();
				cont.append("insert into member values(?,?,?,?,?,?)");
				System.out.println(cont.toString());
			}
		});
		JButton cancelb = new JButton("취소");
		panel_1.add(cancelb);
		cancelb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
}