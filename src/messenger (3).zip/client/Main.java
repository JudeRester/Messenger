package messenger.client;

public class Main {
	public static void main(String[] args) {
		LogInWindow L = new LogInWindow();
		L.setVisible(true);
		L.setTitle("J Messenger");
		
	}
}
